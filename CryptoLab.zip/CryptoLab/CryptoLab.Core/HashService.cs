using System.Numerics;
using System.Security.Cryptography;
using System.Text;

namespace CryptoLab.Core;

/// <summary>8. SHA-256 và đánh giá hiệu ứng lan truyền (avalanche).</summary>
public static class HashService
{
    public static byte[] Sha256(string text) => SHA256.HashData(Encoding.UTF8.GetBytes(text));

    /// <summary>Số bit khác nhau giữa 2 chuỗi băm (trên tổng 256).</summary>
    public static int DiffBits(byte[] a, byte[] b)
    {
        int c = 0;
        for (int i = 0; i < a.Length; i++) c += BitOperations.PopCount((uint)(a[i] ^ b[i]));
        return c;
    }

    /// <summary>Lật 1 bit của đầu vào rồi băm lại -> trung bình bao nhiêu bit đầu ra đổi?</summary>
    public static (double avgBits, int min, int max) AvalancheTest(byte[] input, int rounds = 200)
    {
        var baseHash = SHA256.HashData(input);
        var rnd = new Random();
        int sum = 0, min = 256, max = 0;
        for (int i = 0; i < rounds; i++)
        {
            var copy = (byte[])input.Clone();
            copy[rnd.Next(copy.Length)] ^= (byte)(1 << rnd.Next(8));
            int d = DiffBits(baseHash, SHA256.HashData(copy));
            sum += d; min = Math.Min(min, d); max = Math.Max(max, d);
        }
        return ((double)sum / rounds, min, max);
    }
}
