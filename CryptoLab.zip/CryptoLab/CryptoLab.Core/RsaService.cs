using System.Diagnostics;
using System.Security.Cryptography;

namespace CryptoLab.Core;

/// <summary>Bài 2: RSA — sinh khoá, PEM, import, mã hoá/giải mã, benchmark.</summary>
public static class RsaService
{
    // RSA-2048 + OAEP-SHA256: tối đa 256 - 2*32 - 2 = 190 byte  (khớp đề "không quá 190 byte")
    public static readonly RSAEncryptionPadding Padding = RSAEncryptionPadding.OaepSHA256;
    public static int MaxPlainBytes(int keyBits) => keyBits / 8 - 2 * 32 - 2;

    /// <summary>1. Sinh cặp khoá.</summary>
    public static RSA GenerateKeyPair(int bits = 2048) => RSA.Create(bits);

    /// <summary>2. Xuất cặp khoá ra file PEM (public: SPKI, private: PKCS#8).</summary>
    public static void ExportPem(RSA rsa, string publicPath, string privatePath)
    {
        File.WriteAllText(publicPath, rsa.ExportSubjectPublicKeyInfoPem());
        File.WriteAllText(privatePath, rsa.ExportPkcs8PrivateKeyPem());
    }

    /// <summary>4. Nhập PEM (tự nhận public / private).</summary>
    public static RSA ImportPem(string pemText)
    {
        var rsa = RSA.Create();
        rsa.ImportFromPem(pemText);
        return rsa;
    }

    public static bool IsPrivate(string pemText) => pemText.Contains("PRIVATE KEY");

    /// <summary>4. Đọc ra các thành phần: n, e (public) và n, e, d, p, q, dP, dQ, qInv (private).</summary>
    public static string DescribeKey(RSA rsa, bool includePrivate)
    {
        var p = rsa.ExportParameters(includePrivate);
        string H(byte[]? b) => b == null ? "-" : Convert.ToHexString(b);
        var s = $"Độ dài khoá: {rsa.KeySize} bit\r\n\r\nn (modulus, {p.Modulus!.Length} byte):\r\n{H(p.Modulus)}\r\n\r\ne (public exponent): {H(p.Exponent)}  (= {new System.Numerics.BigInteger(p.Exponent!, true, true)})\r\n";
        if (includePrivate)
            s += $"\r\nd (private exponent):\r\n{H(p.D)}\r\n\r\np:\r\n{H(p.P)}\r\n\r\nq:\r\n{H(p.Q)}\r\n\r\ndP = d mod (p-1):\r\n{H(p.DP)}\r\n\r\ndQ = d mod (q-1):\r\n{H(p.DQ)}\r\n\r\nqInv = q^-1 mod p:\r\n{H(p.InverseQ)}\r\n";
        return s;
    }

    /// <summary>5. Mã hoá mảng byte (<= 190 byte) -> base64.</summary>
    public static string Encrypt(RSA rsa, byte[] data)
    {
        int max = MaxPlainBytes(rsa.KeySize);
        if (data.Length > max) throw new ArgumentException($"Dữ liệu tối đa {max} byte, hiện có {data.Length}.");
        return Convert.ToBase64String(rsa.Encrypt(data, Padding));
    }

    /// <summary>6. Giải mã từ base64 (nội dung file).</summary>
    public static byte[] Decrypt(RSA rsa, string base64) =>
        rsa.Decrypt(Convert.FromBase64String(base64.Trim()), Padding);

    /// <summary>7. Đo tốc độ: n lần mã hoá bằng public key, n lần giải mã bằng private key.</summary>
    public static (double encMsPerOp, double decMsPerOp) Benchmark(RSA rsa, int iterations = 200)
    {
        var data = RandomNumberGenerator.GetBytes(32);
        rsa.Encrypt(data, Padding); // warm-up
        var cipher = rsa.Encrypt(data, Padding);
        rsa.Decrypt(cipher, Padding);

        var sw = Stopwatch.StartNew();
        for (int i = 0; i < iterations; i++) rsa.Encrypt(data, Padding);
        double enc = sw.Elapsed.TotalMilliseconds / iterations;
        sw.Restart();
        for (int i = 0; i < iterations; i++) rsa.Decrypt(cipher, Padding);
        double dec = sw.Elapsed.TotalMilliseconds / iterations;
        return (enc, dec);
    }
}
