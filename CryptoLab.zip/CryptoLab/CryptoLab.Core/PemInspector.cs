using System.Text;

namespace CryptoLab.Core;

/// <summary>3. View PEM: tách header/base64, giải DER và chú thích ý nghĩa từng byte (TLV).</summary>
public static class PemInspector
{
    private static readonly Dictionary<string, string> Oids = new()
    {
        ["1.2.840.113549.1.1.1"] = "rsaEncryption",
    };

    public static string Inspect(string pemText)
    {
        var lines = pemText.Split('\n', StringSplitOptions.RemoveEmptyEntries).Select(l => l.Trim()).ToList();
        var header = lines.First(l => l.StartsWith("-----BEGIN"));
        var footer = lines.First(l => l.StartsWith("-----END"));
        var b64 = string.Concat(lines.Where(l => !l.StartsWith("-----")));
        var der = Convert.FromBase64String(b64);

        var sb = new StringBuilder();
        sb.AppendLine("Cấu trúc file PEM:");
        sb.AppendLine($"  {header}   <- dòng mở đầu, cho biết loại dữ liệu");
        sb.AppendLine($"  <base64 của khối DER, {der.Length} byte>   <- {b64.Length} ký tự, mỗi dòng 64 ký tự");
        sb.AppendLine($"  {footer}   <- dòng kết thúc");
        sb.AppendLine();
        sb.AppendLine("Giải mã DER (ASN.1) — mỗi phần tử = Tag (1B) + Length (1-n B) + Value:");
        sb.AppendLine();
        int pos = 0;
        _idx = 0;
        _labels = header.Contains("PRIVATE") ? new[] { "version", "n (modulus)", "e (public exponent)", "d (private exponent)", "p (prime 1)", "q (prime 2)", "dP = d mod (p-1)", "dQ = d mod (q-1)", "qInv = q^-1 mod p" }
                                             : new[] { "n (modulus)", "e (public exponent)" };
        Walk(der, ref pos, der.Length, 0, sb);
        return sb.ToString();
    }

    private static void Walk(byte[] d, ref int pos, int end, int depth, StringBuilder sb)
    {
        while (pos < end)
        {
            int start = pos;
            byte tag = d[pos++];
            int len = d[pos++];
            int lenBytes = 1;
            if ((len & 0x80) != 0)
            {
                int k = len & 0x7F; lenBytes = 1 + k; len = 0;
                for (int i = 0; i < k; i++) len = (len << 8) | d[pos++];
            }
            string ind = new(' ', depth * 2);
            string name = tag switch
            {
                0x30 => "SEQUENCE", 0x02 => "INTEGER", 0x03 => "BIT STRING", 0x04 => "OCTET STRING",
                0x05 => "NULL", 0x06 => "OBJECT IDENTIFIER", _ => $"tag 0x{tag:X2}"
            };
            string hdr = $"{ind}[offset {start,4}] {tag:X2} {(lenBytes > 1 ? "8" + (lenBytes - 1) + " " : "")}{(lenBytes > 1 ? len.ToString("X") : len.ToString("X2"))}".PadRight(0);
            sb.Append($"{ind}[off {start,4}] {name}  (tag=0x{tag:X2}, len={len} byte)");

            if (tag == 0x30 || tag == 0x03 && false)
            {
                sb.AppendLine();
                int innerEnd = pos + len;
                Walk(d, ref pos, innerEnd, depth + 1, sb);
            }
            else if (tag == 0x03 || tag == 0x04)
            {
                // BIT STRING (public key) / OCTET STRING (private key) thường chứa DER lồng bên trong
                int skip = tag == 0x03 ? 1 : 0; // BIT STRING có 1 byte "unused bits"
                sb.AppendLine(tag == 0x03 ? "  <- chứa khoá RSAPublicKey (DER lồng bên trong)" : "  <- chứa RSAPrivateKey (DER lồng bên trong)");
                int innerEnd = pos + len; pos += skip;
                Walk(d, ref pos, innerEnd, depth + 1, sb);
            }
            else if (tag == 0x02)
            {
                var v = d.AsSpan(pos, len).ToArray();
                sb.AppendLine($"  = {Short(v)}{Meaning(v, depth)}");
                pos += len;
            }
            else if (tag == 0x06)
            {
                var oid = DecodeOid(d.AsSpan(pos, len));
                sb.AppendLine($"  = {oid}  {(Oids.TryGetValue(oid, out var n) ? "(" + n + ")" : "")}");
                pos += len;
            }
            else { sb.AppendLine(); pos += len; }
        }
    }

    private static int _idx;
    private static string[] _labels = Array.Empty<string>();
    private static string Meaning(byte[] v, int depth) =>
        depth == 1 ? "   <- version của PKCS#8"
        : _idx < _labels.Length ? "   <- " + _labels[_idx++] : "";

    private static string Short(byte[] v)
    {
        var hex = Convert.ToHexString(v);
        return hex.Length <= 24 ? "0x" + hex : $"0x{hex[..16]}…{hex[^8..]}  ({v.Length} byte)";
    }

    private static string DecodeOid(ReadOnlySpan<byte> b)
    {
        var parts = new List<long> { b[0] / 40, b[0] % 40 };
        long val = 0;
        for (int i = 1; i < b.Length; i++)
        {
            val = (val << 7) | (uint)(b[i] & 0x7F);
            if ((b[i] & 0x80) == 0) { parts.Add(val); val = 0; }
        }
        return string.Join('.', parts);
    }
}
