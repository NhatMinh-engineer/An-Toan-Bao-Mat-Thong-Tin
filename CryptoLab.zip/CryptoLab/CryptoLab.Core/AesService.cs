using System.Diagnostics;
using System.Security.Cryptography;

namespace CryptoLab.Core;

/// <summary>Bài 1: AES-256-CBC, xử lý file theo stream (file hàng GB không tốn RAM).</summary>
public static class AesService
{
    private const int BufferSize = 1024 * 1024; // 1 MB

    /// <summary>1. Sinh khoá AES-256 (32 byte).</summary>
    public static byte[] GenerateKey() => RandomNumberGenerator.GetBytes(32);

    /// <summary>2. Lưu khoá ra file (base64).</summary>
    public static void SaveKey(byte[] key, string path) =>
        File.WriteAllText(path, Convert.ToBase64String(key));

    /// <summary>3. Import khoá từ file.</summary>
    public static byte[] LoadKey(string path)
    {
        var key = Convert.FromBase64String(File.ReadAllText(path).Trim());
        if (key.Length != 32) throw new InvalidDataException("Khoá AES phải 32 byte (256 bit).");
        return key;
    }

    /// <summary>4. Mã hoá văn bản -> base64 (IV 16 byte đứng đầu).</summary>
    public static string EncryptText(string plain, byte[] key)
    {
        using var aes = Aes.Create();
        aes.Key = key; aes.GenerateIV();
        var cipher = aes.EncryptCbc(System.Text.Encoding.UTF8.GetBytes(plain), aes.IV);
        return Convert.ToBase64String(aes.IV.Concat(cipher).ToArray());
    }

    public static string DecryptText(string base64, byte[] key)
    {
        var all = Convert.FromBase64String(base64);
        using var aes = Aes.Create();
        aes.Key = key;
        var plain = aes.DecryptCbc(all.AsSpan(16), all.AsSpan(0, 16));
        return System.Text.Encoding.UTF8.GetString(plain);
    }

    /// <summary>5. Mã hoá file -> file. Định dạng: [IV 16B][ciphertext]. Trả về thời gian.</summary>
    public static TimeSpan EncryptFile(string inPath, string outPath, byte[] key,
        IProgress<double>? progress = null, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        using var aes = Aes.Create();
        aes.Key = key; aes.GenerateIV();
        using var fin = new FileStream(inPath, FileMode.Open, FileAccess.Read, FileShare.Read, BufferSize, FileOptions.SequentialScan);
        using var fout = new FileStream(outPath, FileMode.Create, FileAccess.Write, FileShare.None, BufferSize, FileOptions.SequentialScan);
        fout.Write(aes.IV, 0, 16);
        using var cs = new CryptoStream(fout, aes.CreateEncryptor(), CryptoStreamMode.Write);
        Pump(fin, cs, fin.Length, progress, ct);
        cs.FlushFinalBlock();
        return sw.Elapsed;
    }

    public static TimeSpan DecryptFile(string inPath, string outPath, byte[] key,
        IProgress<double>? progress = null, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        using var fin = new FileStream(inPath, FileMode.Open, FileAccess.Read, FileShare.Read, BufferSize, FileOptions.SequentialScan);
        var iv = new byte[16];
        fin.ReadExactly(iv);
        using var aes = Aes.Create();
        aes.Key = key; aes.IV = iv;
        using var fout = new FileStream(outPath, FileMode.Create, FileAccess.Write, FileShare.None, BufferSize, FileOptions.SequentialScan);
        using var cs = new CryptoStream(fin, aes.CreateDecryptor(), CryptoStreamMode.Read);
        Pump(cs, fout, fin.Length, progress, ct, fin);
        return sw.Elapsed;
    }

    private static void Pump(Stream src, Stream dst, long total, IProgress<double>? progress,
        CancellationToken ct, Stream? positionSource = null)
    {
        var buf = new byte[BufferSize];
        int n;
        while ((n = src.Read(buf, 0, buf.Length)) > 0)
        {
            ct.ThrowIfCancellationRequested();
            dst.Write(buf, 0, n);
            progress?.Report(total == 0 ? 1 : (double)(positionSource ?? src).Position / total);
        }
    }

    /// <summary>So sánh 2 file theo từng byte (stream, dừng ở byte khác đầu tiên). -1 nếu giống hệt.</summary>
    public static long CompareFiles(string a, string b)
    {
        using var fa = new FileStream(a, FileMode.Open, FileAccess.Read, FileShare.Read, BufferSize);
        using var fb = new FileStream(b, FileMode.Open, FileAccess.Read, FileShare.Read, BufferSize);
        if (fa.Length != fb.Length) return Math.Min(fa.Length, fb.Length);
        var ba = new byte[BufferSize]; var bb = new byte[BufferSize];
        long pos = 0;
        while (true)
        {
            int na = fa.Read(ba, 0, ba.Length);
            if (na == 0) return -1;
            fb.ReadExactly(bb, 0, na);
            var idx = ba.AsSpan(0, na).CommonPrefixLength(bb.AsSpan(0, na));
            if (idx < na) return pos + idx;
            pos += na;
        }
    }
}
