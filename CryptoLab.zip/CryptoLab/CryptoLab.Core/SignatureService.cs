using System.Security.Cryptography;

namespace CryptoLab.Core;

/// <summary>
/// 9. Chữ ký số. Yêu cầu: cùng dữ liệu + cùng private key -> mỗi lần ký ra chữ ký KHÁC nhau,
/// nhưng vẫn verify đúng. Giải pháp: RSASSA-PSS (padding ngẫu nhiên, salt 32 byte mỗi lần ký).
/// (PKCS#1 v1.5 là tất định -> luôn ra cùng chữ ký.)
/// </summary>
public static class SignatureService
{
    public static byte[] SignPss(RSA privateKey, byte[] data) =>
        privateKey.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);

    public static bool VerifyPss(RSA publicKey, byte[] data, byte[] sig) =>
        publicKey.VerifyData(data, sig, HashAlgorithmName.SHA256, RSASignaturePadding.Pss);

    public static byte[] SignPkcs1(RSA privateKey, byte[] data) =>
        privateKey.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);

    public static bool VerifyPkcs1(RSA publicKey, byte[] data, byte[] sig) =>
        publicKey.VerifyData(data, sig, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
}
