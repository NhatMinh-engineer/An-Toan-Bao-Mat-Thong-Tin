# Crypto Lab — Thiết kế (môn An toàn & Bảo mật thông tin)

## 1. Kiến trúc
Tách 3 lớp để logic mật mã dùng chung, không dính UI:

```
CryptoLab.Core      (class library, không phụ thuộc UI)
  AesService        Bài 1: sinh/lưu/import khoá, mã hoá text, mã hoá file (stream)
  RsaService        Bài 2: sinh khoá, xuất/nhập PEM, mã hoá/giải mã, benchmark
  PemInspector      Bài 2.3: giải DER/ASN.1, chú thích từng trường
  HashService       Bài 8: SHA-256 + đo avalanche
  SignatureService  Bài 9: chữ ký số PSS / PKCS#1
CryptoLab.WinForms  UI: 4 tab (AES, RSA, SHA-256, Chữ ký số)
CryptoLab.Console   Menu console + `selftest` để kiểm thử nhanh
```

## 2. Quyết định thiết kế (và lý do)

| Yêu cầu | Quyết định | Lý do |
|---|---|---|
| AES khoá 256 bit | `Aes` + khoá 32 byte, lưu **base64** | khớp đề: 256 bit = 32 byte |
| AES file hàng GB | `FileStream` + `CryptoStream`, buffer **1 MB**, `SequentialScan` | RAM cố định ~vài MB, không đọc cả file vào bộ nhớ |
| AES chế độ | **CBC + PKCS7**, IV ngẫu nhiên 16 byte ghi **đầu file/chuỗi** | IV không cần bí mật, mỗi lần mã hoá IV khác → cùng bản rõ ra bản mã khác |
| So sánh file | so từng khối 1 MB bằng `CommonPrefixLength`, trả về vị trí byte khác đầu tiên (-1 = giống) | đúng yêu cầu "compare theo bytes", không tốn RAM |
| Thời gian | `Stopwatch` quanh mã hoá / giải mã, in MB/s | để rút ra kết luận từ số liệu |
| RSA | 2048 bit; xuất **PEM**: public = SPKI (`BEGIN PUBLIC KEY`), private = PKCS#8 (`BEGIN PRIVATE KEY`) | định dạng chuẩn, OpenSSL đọc được |
| Giới hạn 190 byte | **OAEP-SHA256**: 256 − 2×32 − 2 = **190 byte** | đây chính là lý do con số 190 trong đề |
| Lưu bản mã RSA | base64 ra file | đúng đề: "lưu ở dạng base64 => lưu file" |
| View PEM | parser TLV (Tag-Length-Value) tự viết, hiển thị offset, tag, len, nhãn n/e/d/p/q/dP/dQ/qInv | trả lời "ý nghĩa các byte trong PEM" |
| Đánh giá tốc độ RSA | lặp 200 lần, có warm-up, lấy ms/lần | giảm nhiễu JIT |
| SHA-256 | UI băm realtime khi gõ, hiển thị số bit khác so với lần trước + thống kê lật 1 bit × 200 | đánh giá hiệu ứng lan truyền |
| Chữ ký khác nhau mỗi lần | **RSASSA-PSS** (xem 4) | giải đáp câu 9 |

## 3. Luồng chính
- **AES file:** đọc 1 MB → CryptoStream → ghi; file mã hoá = `[IV 16B][ciphertext]`.
- **RSA:** `sinh cặp khoá → xuất 2 file PEM → import lại → Encrypt(public) → base64 → file → Decrypt(private) → so sánh với bản gốc`.
- **Ký:** `hash = SHA256(data)` → RSA-PSS bằng private key → chữ ký; verify bằng public key.

## 4. Trả lời các câu hỏi lý thuyết trong đề

**Bài 2.7 — tốc độ:** public key dùng e nhỏ (65537, chỉ ~17 bit, 2 phép nhân bình phương + 1 nhân) nên mã hoá nhanh; private key dùng d cỡ 2048 bit nên giải mã chậm hơn khoảng 10–15 lần (đo thực tế trong máy chạy thử: enc 0.03 ms, dec 0.39 ms). .NET còn dùng CRT (p, q, dP, dQ, qInv) để tăng tốc giải mã.

**Bài 8 — SHA-256:** đổi 1 bit đầu vào thì ~50% (≈128/256) bit đầu ra đổi (đo: TB 127/256 = 49.6%). Đây là hiệu ứng lan truyền (avalanche). Lưu ý: đề ghi "(rất ít)" nhưng kết quả thực tế là **thay đổi rất nhiều** ở đầu ra, chỉ đầu vào thay đổi rất ít.

**Bài 9 — cùng dữ liệu, cùng private key, mỗi lần ký ra chữ ký khác:**
- Vấn đề: RSA PKCS#1 v1.5 là tất định → luôn ra cùng chữ ký.
- Giải pháp: dùng **RSASSA-PSS** — mỗi lần ký chọn salt ngẫu nhiên (32 byte), trộn vào hash bằng MGF1 trước khi luỹ thừa bằng d. Chữ ký khác nhau mỗi lần nhưng verify (có biết độ dài salt) vẫn đúng với bất kỳ chữ ký nào.
- Phương án khác (kém chuẩn hơn): ghép nonce/timestamp vào dữ liệu trước khi ký, nhưng khi đó "dữ liệu" đã khác và người verify phải biết nonce.

## 5. Chạy
```
dotnet run --project CryptoLab.Console              # menu console
dotnet run --project CryptoLab.Console -- selftest  # test tự động
dotnet run --project CryptoLab.WinForms             # giao diện (Windows, cần .NET 8)
```
Kết quả selftest trên máy thử: AES 300 MB mã hoá 0.50 s / giải mã 0.25 s, so sánh byte = giống hệt; RSA 190 byte khứ hồi đúng, 191 byte bị từ chối; PSS 2 lần ký khác nhau, verify đều True, sửa dữ liệu thì False.
