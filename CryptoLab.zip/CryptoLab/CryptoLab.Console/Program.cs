using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using CryptoLab.Core;

// Menu console. Chạy: dotnet run --project CryptoLab.Console   |   dotnet run --project CryptoLab.Console -- selftest
if (args.Contains("selftest")) { SelfTest.Run(); return; }

byte[]? aesKey = null; RSA? pub = null, priv = null;
while (true)
{
    Console.WriteLine("\n===== CRYPTO LAB =====");
    Console.WriteLine("-- AES --\n 1. Sinh khoá AES  2. Lưu khoá  3. Import khoá  4. Mã hoá văn bản  5. Mã hoá file  5b. Giải mã file");
    Console.WriteLine("-- RSA --\n 6. Sinh cặp khoá + xuất PEM  7. View PEM  8. Import public  9. Import private\n 10. Mã hoá (public)  11. Giải mã (private)  12. Benchmark");
    Console.WriteLine("-- Khác --\n 13. SHA-256 avalanche  14. Chữ ký số (PSS vs PKCS1)  0. Thoát");
    Console.Write("> ");
    var c = Console.ReadLine()?.Trim();
    try
    {
        switch (c)
        {
            case "1": aesKey = AesService.GenerateKey(); Console.WriteLine("Key: " + Convert.ToBase64String(aesKey)); break;
            case "2": AesService.SaveKey(aesKey!, Ask("Đường dẫn lưu khoá")); break;
            case "3": aesKey = AesService.LoadKey(Ask("Đường dẫn file khoá")); break;
            case "4": Console.WriteLine(AesService.EncryptText(Ask("Văn bản"), aesKey!)); break;
            case "5":
                var t = AesService.EncryptFile(Ask("File nguồn"), Ask("File đích"), aesKey!, new Progress<double>(p => Console.Write($"\r{p:P0}")));
                Console.WriteLine($"\nMã hoá xong: {t.TotalSeconds:F2}s"); break;
            case "5b":
                string src = Ask("File mã hoá"), dst = Ask("File giải mã ra"), orig = Ask("File gốc (để so sánh)");
                var td = AesService.DecryptFile(src, dst, aesKey!, new Progress<double>(p => Console.Write($"\r{p:P0}")));
                long diff = AesService.CompareFiles(orig, dst);
                Console.WriteLine($"\nGiải mã: {td.TotalSeconds:F2}s | {(diff < 0 ? "GIỐNG HỆT từng byte" : "KHÁC tại byte " + diff)}"); break;
            case "6":
                var rsa = RsaService.GenerateKeyPair();
                RsaService.ExportPem(rsa, Ask("File public.pem"), Ask("File private.pem")); break;
            case "7": Console.WriteLine(PemInspector.Inspect(File.ReadAllText(Ask("File PEM")))); break;
            case "8": pub = RsaService.ImportPem(File.ReadAllText(Ask("public.pem"))); Console.WriteLine(RsaService.DescribeKey(pub, false)); break;
            case "9": priv = RsaService.ImportPem(File.ReadAllText(Ask("private.pem"))); Console.WriteLine(RsaService.DescribeKey(priv, true)); break;
            case "10":
                var data = Encoding.UTF8.GetBytes(Ask($"Dữ liệu (<= {RsaService.MaxPlainBytes(pub!.KeySize)} byte)"));
                var ct = RsaService.Encrypt(pub, data); File.WriteAllText(Ask("File lưu ciphertext"), ct); Console.WriteLine(ct); break;
            case "11": Console.WriteLine(Encoding.UTF8.GetString(RsaService.Decrypt(priv!, File.ReadAllText(Ask("File ciphertext"))))); break;
            case "12":
                var (e, d) = RsaService.Benchmark(priv ?? RsaService.GenerateKeyPair());
                Console.WriteLine($"Public key (e bé)  : {e:F3} ms/lần\nPrivate key (d lớn): {d:F3} ms/lần\nGiải mã chậm hơn ~{d / e:F0} lần"); break;
            case "13": SelfTest.Avalanche(Ask("Chuỗi đầu vào")); break;
            case "14": SelfTest.Signature(Ask("Dữ liệu")); break;
            case "0": return;
        }
    }
    catch (Exception ex) { Console.WriteLine("LỖI: " + ex.Message); }
}

static string Ask(string p) { Console.Write(p + ": "); return Console.ReadLine()!.Trim().Trim('"'); }

static class SelfTest
{
    public static void Avalanche(string s)
    {
        var h1 = HashService.Sha256(s);
        var h2 = HashService.Sha256(s + ".");
        Console.WriteLine($"SHA256('{s}')  = {Convert.ToHexString(h1)}");
        Console.WriteLine($"SHA256('{s}.') = {Convert.ToHexString(h2)}");
        Console.WriteLine($"Khác nhau {HashService.DiffBits(h1, h2)}/256 bit");
        var (avg, min, max) = HashService.AvalancheTest(Encoding.UTF8.GetBytes(s));
        Console.WriteLine($"Lật 1 bit đầu vào x200 lần: TB {avg:F1}/256 bit đổi ({avg / 2.56:F1}%), min {min}, max {max}");
    }

    public static void Signature(string s)
    {
        using var rsa = RsaService.GenerateKeyPair();
        var data = Encoding.UTF8.GetBytes(s);
        var p1 = SignatureService.SignPkcs1(rsa, data); var p2 = SignatureService.SignPkcs1(rsa, data);
        var s1 = SignatureService.SignPss(rsa, data); var s2 = SignatureService.SignPss(rsa, data);
        Console.WriteLine($"PKCS#1 v1.5: 2 lần ký giống nhau? {p1.SequenceEqual(p2)}");
        Console.WriteLine($"PSS        : 2 lần ký giống nhau? {s1.SequenceEqual(s2)} | verify1={SignatureService.VerifyPss(rsa, data, s1)} verify2={SignatureService.VerifyPss(rsa, data, s2)}");
        Console.WriteLine($"PSS sai dữ liệu verify? {SignatureService.VerifyPss(rsa, Encoding.UTF8.GetBytes(s + "x"), s1)}");
    }

    public static void Run()
    {
        var tmp = Path.Combine(Path.GetTempPath(), "cl"); Directory.CreateDirectory(tmp);
        // AES file 300MB
        var key = AesService.GenerateKey();
        var f = Path.Combine(tmp, "big.bin");
        using (var fs = File.Create(f)) { var b = new byte[1 << 20]; new Random(1).NextBytes(b); for (int i = 0; i < 300; i++) fs.Write(b); }
        var te = AesService.EncryptFile(f, f + ".enc", key);
        var td = AesService.DecryptFile(f + ".enc", f + ".dec", key);
        Console.WriteLine($"AES 300MB: enc {te.TotalSeconds:F2}s dec {td.TotalSeconds:F2}s compare={AesService.CompareFiles(f, f + ".dec")} (-1 = giống)");
        Console.WriteLine("AES text: " + AesService.DecryptText(AesService.EncryptText("xin chào", key), key));
        // RSA
        using var rsa = RsaService.GenerateKeyPair();
        RsaService.ExportPem(rsa, tmp + "/pub.pem", tmp + "/priv.pem");
        var pub = RsaService.ImportPem(File.ReadAllText(tmp + "/pub.pem"));
        var priv = RsaService.ImportPem(File.ReadAllText(tmp + "/priv.pem"));
        var msg = RandomNumberGenerator.GetBytes(190);
        Console.WriteLine("RSA 190B roundtrip: " + RsaService.Decrypt(priv, RsaService.Encrypt(pub, msg)).SequenceEqual(msg));
        try { RsaService.Encrypt(pub, new byte[191]); } catch (Exception e) { Console.WriteLine("191B -> " + e.Message); }
        Console.WriteLine(PemInspector.Inspect(File.ReadAllText(tmp + "/pub.pem")));
        Console.WriteLine(PemInspector.Inspect(File.ReadAllText(tmp + "/priv.pem")));
        var (en, de) = RsaService.Benchmark(priv);
        Console.WriteLine($"RSA bench: enc {en:F3}ms dec {de:F3}ms");
        Avalanche("hello"); Signature("hợp đồng số 1");
    }
}
