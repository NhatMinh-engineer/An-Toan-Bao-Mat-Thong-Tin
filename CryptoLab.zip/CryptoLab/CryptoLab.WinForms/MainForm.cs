using System.Security.Cryptography;
using System.Text;
using CryptoLab.Core;

namespace CryptoLab.WinForms;

public class MainForm : Form
{
    private byte[]? _aesKey;
    private RSA? _pub, _priv;

    // --- controls ---
    private readonly TextBox _aesKeyBox = Box(), _aesPlain = Box(multi: true), _aesCipher = Box(multi: true),
        _aesSrc = Box(), _aesDst = Box(), _aesLog = Box(multi: true);
    private readonly ProgressBar _aesProg = new() { Dock = DockStyle.Top, Height = 18 };
    private readonly TextBox _rsaPemView = Box(multi: true), _rsaKeyInfo = Box(multi: true), _rsaPlain = Box(multi: true),
        _rsaCipher = Box(multi: true), _rsaLog = Box(multi: true);
    private readonly TextBox _hashIn = Box(), _hashOut = Box(multi: true);
    private readonly TextBox _sigIn = Box(multi: true), _sigOut = Box(multi: true);

    public MainForm()
    {
        Text = "Crypto Lab — AES / RSA / SHA-256 / Chữ ký số";
        Width = 1000; Height = 720; StartPosition = FormStartPosition.CenterScreen;
        var tabs = new TabControl { Dock = DockStyle.Fill };
        tabs.TabPages.Add(BuildAesTab());
        tabs.TabPages.Add(BuildRsaTab());
        tabs.TabPages.Add(BuildHashTab());
        tabs.TabPages.Add(BuildSigTab());
        Controls.Add(tabs);
    }

    // ===== helpers =====
    private static TextBox Box(bool multi = false) => new()
    { Multiline = multi, Dock = DockStyle.Fill, ScrollBars = multi ? ScrollBars.Vertical : ScrollBars.None, Font = new Font("Consolas", 10), AcceptsReturn = multi };
    private static Button Btn(string text, EventHandler onClick) { var b = new Button { Text = text, AutoSize = true, Margin = new Padding(3) }; b.Click += onClick; return b; }
    private static FlowLayoutPanel Row(params Control[] c) { var f = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, WrapContents = true }; f.Controls.AddRange(c); return f; }
    private static Label Lbl(string t) => new() { Text = t, Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(0, 6, 0, 2), Font = new Font(SystemFonts.DefaultFont, FontStyle.Bold) };
    private static void Err(Exception ex) => MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
    private static string? Open(string filter = "All|*.*") { using var d = new OpenFileDialog { Filter = filter }; return d.ShowDialog() == DialogResult.OK ? d.FileName : null; }
    private static string? Save(string filter = "All|*.*") { using var d = new SaveFileDialog { Filter = filter }; return d.ShowDialog() == DialogResult.OK ? d.FileName : null; }
    private static void Guard(Action a) { try { a(); } catch (Exception ex) { Err(ex); } }
    private static Panel Stack(params Control[] controlsTopToBottom)
    {
        var p = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8), AutoScroll = true };
        foreach (var c in controlsTopToBottom.Reverse()) p.Controls.Add(c);
        return p;
    }
    private static Control Sized(TextBox t, int h) { t.Dock = DockStyle.Top; t.Height = h; return t; }

    // ===== Tab 1: AES =====
    private TabPage BuildAesTab()
    {
        var tab = new TabPage("Bài 1 — AES");
        _aesKeyBox.ReadOnly = true;
        tab.Controls.Add(Stack(
            Lbl("Khoá AES-256 (base64)"), Sized(_aesKeyBox, 24),
            Row(Btn("1. Sinh khoá", (_, _) => { _aesKey = AesService.GenerateKey(); _aesKeyBox.Text = Convert.ToBase64String(_aesKey); }),
                Btn("2. Lưu khoá ra file", (_, _) => Guard(() => { if (_aesKey == null) throw new Exception("Chưa có khoá."); var p = Save("Key|*.key"); if (p != null) AesService.SaveKey(_aesKey, p); })),
                Btn("3. Import khoá từ file", (_, _) => Guard(() => { var p = Open("Key|*.key|All|*.*"); if (p != null) { _aesKey = AesService.LoadKey(p); _aesKeyBox.Text = Convert.ToBase64String(_aesKey); } }))),
            Lbl("4. Văn bản gốc"), Sized(_aesPlain, 70),
            Row(Btn("Mã hoá ↓", (_, _) => Guard(() => _aesCipher.Text = AesService.EncryptText(_aesPlain.Text, NeedKey()))),
                Btn("Giải mã ↑", (_, _) => Guard(() => _aesPlain.Text = AesService.DecryptText(_aesCipher.Text.Trim(), NeedKey())))),
            Lbl("Kết quả mã hoá (base64)"), Sized(_aesCipher, 70),
            Lbl("5. Mã hoá / giải mã FILE (stream 1MB — chạy được file hàng GB)"),
            Row(Btn("Chọn file nguồn…", (_, _) => { var p = Open(); if (p != null) _aesSrc.Text = p; })),
            Sized(_aesSrc, 24),
            Row(Btn("Chọn file đích…", (_, _) => { var p = Save(); if (p != null) _aesDst.Text = p; })),
            Sized(_aesDst, 24),
            Row(Btn("Mã hoá file", async (_, _) => await RunFile(true)), Btn("Giải mã file", async (_, _) => await RunFile(false)),
                Btn("So sánh 2 file theo byte…", (_, _) => Guard(CompareDialog))),
            _aesProg,
            Lbl("Nhật ký (thời gian, kết quả so sánh)"), Sized(_aesLog, 150)));
        return tab;
    }

    private byte[] NeedKey() => _aesKey ?? throw new Exception("Chưa có khoá AES (sinh hoặc import).");

    private async Task RunFile(bool encrypt)
    {
        try
        {
            var key = NeedKey(); string src = _aesSrc.Text, dst = _aesDst.Text;
            if (!File.Exists(src) || string.IsNullOrWhiteSpace(dst)) throw new Exception("Chọn file nguồn và file đích.");
            var prog = new Progress<double>(p => _aesProg.Value = (int)Math.Clamp(p * 100, 0, 100));
            var t = await Task.Run(() => encrypt ? AesService.EncryptFile(src, dst, key, prog) : AesService.DecryptFile(src, dst, key, prog));
            long size = new FileInfo(src).Length;
            _aesLog.AppendText($"{(encrypt ? "Mã hoá" : "Giải mã")} {size / 1048576.0:F1} MB: {t.TotalSeconds:F2} s ({size / 1048576.0 / t.TotalSeconds:F0} MB/s)\r\n");
        }
        catch (Exception ex) { Err(ex); }
    }

    private void CompareDialog()
    {
        var a = Open(); if (a == null) return; var b = Open(); if (b == null) return;
        long diff = AesService.CompareFiles(a, b);
        _aesLog.AppendText(diff < 0 ? "So sánh byte: GIỐNG HỆT.\r\n" : $"So sánh byte: KHÁC tại byte #{diff}.\r\n");
    }

    // ===== Tab 2: RSA =====
    private TabPage BuildRsaTab()
    {
        var tab = new TabPage("Bài 2 — RSA");
        _rsaPemView.ReadOnly = true; _rsaKeyInfo.ReadOnly = true; _rsaLog.ReadOnly = true;
        tab.Controls.Add(Stack(
            Row(Btn("1+2. Sinh cặp khoá 2048 & xuất PEM", (_, _) => Guard(GenAndExport)),
                Btn("3. View PEM…", (_, _) => Guard(() => { var p = Open("PEM|*.pem|All|*.*"); if (p != null) _rsaPemView.Text = PemInspector.Inspect(File.ReadAllText(p)).Replace("\n", "\r\n"); })),
                Btn("4a. Import public.pem", (_, _) => Guard(() => Import(false))),
                Btn("4b. Import private.pem", (_, _) => Guard(() => Import(true)))),
            Lbl("Giải mã cấu trúc PEM / DER"), Sized(_rsaPemView, 200),
            Lbl("Thành phần khoá vừa import (n, e / d, p, q…)"), Sized(_rsaKeyInfo, 150),
            Lbl("5. Dữ liệu (≤ 190 byte, UTF-8)"), Sized(_rsaPlain, 50),
            Row(Btn("Mã hoá (public) → lưu file base64", (_, _) => Guard(EncryptToFile)),
                Btn("6. Giải mã (private) ← file base64", (_, _) => Guard(DecryptFromFile))),
            Lbl("Ciphertext (base64)"), Sized(_rsaCipher, 60),
            Row(Btn("7. Đánh giá tốc độ", (_, _) => Guard(Bench))),
            Lbl("Kết quả"), Sized(_rsaLog, 90)));
        return tab;
    }

    private void GenAndExport()
    {
        var pubP = Save("Public PEM|*.pem"); if (pubP == null) return;
        var privP = Save("Private PEM|*.pem"); if (privP == null) return;
        using var rsa = RsaService.GenerateKeyPair();
        RsaService.ExportPem(rsa, pubP, privP);
        _rsaLog.Text = $"Đã xuất:\r\n  {pubP}\r\n  {privP}";
    }

    private void Import(bool isPrivate)
    {
        var p = Open("PEM|*.pem|All|*.*"); if (p == null) return;
        var text = File.ReadAllText(p);
        if (RsaService.IsPrivate(text) != isPrivate) throw new Exception(isPrivate ? "File này không phải private key." : "File này không phải public key.");
        var rsa = RsaService.ImportPem(text);
        if (isPrivate) _priv = rsa; else _pub = rsa;
        _rsaKeyInfo.Text = RsaService.DescribeKey(rsa, isPrivate);
    }

    private void EncryptToFile()
    {
        var pub = _pub ?? throw new Exception("Chưa import public key.");
        var ct = RsaService.Encrypt(pub, Encoding.UTF8.GetBytes(_rsaPlain.Text));
        _rsaCipher.Text = ct;
        var p = Save("Text|*.txt"); if (p != null) File.WriteAllText(p, ct);
    }

    private void DecryptFromFile()
    {
        var priv = _priv ?? throw new Exception("Chưa import private key.");
        var p = Open("Text|*.txt|All|*.*"); if (p == null) return;
        var plain = RsaService.Decrypt(priv, File.ReadAllText(p));
        var text = Encoding.UTF8.GetString(plain);
        _rsaLog.Text = $"Giải mã: \"{text}\"\r\nKhớp dữ liệu gốc: {(text == _rsaPlain.Text ? "CÓ" : "KHÔNG")}";
    }

    private void Bench()
    {
        var rsa = _priv ?? throw new Exception("Import private key trước (chứa cả n, e, d).");
        var (e, d) = RsaService.Benchmark(rsa);
        _rsaLog.Text = $"Mã hoá bằng public key (n, e nhỏ): {e:F3} ms/lần\r\nGiải mã bằng private key (n, d lớn): {d:F3} ms/lần\r\nGiải mã chậm hơn ≈ {d / e:F0} lần\r\n→ e nhỏ (65537, ~17 bit) nên luỹ thừa mod nhanh; d ~2048 bit nên chậm.";
    }

    // ===== Tab 3: SHA-256 =====
    private TabPage BuildHashTab()
    {
        var tab = new TabPage("Bài 8 — SHA-256");
        _hashOut.ReadOnly = true;
        string last = "";
        _hashIn.TextChanged += (_, _) =>
        {
            var h = HashService.Sha256(_hashIn.Text);
            var hex = Convert.ToHexString(h);
            string cmp = last.Length == 0 ? "" : $"\r\nBăm trước : {last}\r\nSố bit khác so với lần trước: {HashService.DiffBits(Convert.FromHexString(last), h)}/256 ({HashService.DiffBits(Convert.FromHexString(last), h) / 2.56:F1}%)";
            _hashOut.Text = $"SHA-256: {hex}{cmp}";
            last = hex;
        };
        tab.Controls.Add(Stack(
            Lbl("Nhập chuỗi (băm cập nhật theo từng ký tự gõ) — thử đổi 1 ký tự và xem số bit khác"), Sized(_hashIn, 24),
            Lbl("Kết quả"), Sized(_hashOut, 140),
            Row(Btn("Thống kê: lật 1 bit ngẫu nhiên × 200 lần", (_, _) => Guard(() =>
            {
                var (avg, min, max) = HashService.AvalancheTest(Encoding.UTF8.GetBytes(_hashIn.Text.Length == 0 ? "a" : _hashIn.Text));
                _hashOut.AppendText($"\r\n\r\nAvalanche: TB {avg:F1}/256 bit đổi ({avg / 2.56:F1}%), min {min}, max {max}\r\n→ ≈50%: đổi 1 bit đầu vào làm thay đổi gần một nửa đầu ra.");
            })))));
        return tab;
    }

    // ===== Tab 4: Chữ ký số =====
    private TabPage BuildSigTab()
    {
        var tab = new TabPage("Bài 9 — Chữ ký số");
        _sigOut.ReadOnly = true;
        tab.Controls.Add(Stack(
            Lbl("Dữ liệu cần ký"), Sized(_sigIn, 70),
            Row(Btn("Ký 3 lần: PSS vs PKCS#1 v1.5", (_, _) => Guard(Demo))),
            Lbl("Kết quả"), Sized(_sigOut, 360)));
        return tab;
    }

    private void Demo()
    {
        using var rsa = RsaService.GenerateKeyPair();
        var data = Encoding.UTF8.GetBytes(_sigIn.Text);
        var sb = new StringBuilder();
        sb.AppendLine("== PKCS#1 v1.5 (tất định: padding cố định) ==");
        var a = Enumerable.Range(0, 3).Select(_ => SignatureService.SignPkcs1(rsa, data)).ToList();
        for (int i = 0; i < 3; i++) sb.AppendLine($"Lần {i + 1}: {Convert.ToBase64String(a[i])[..40]}…  verify={SignatureService.VerifyPkcs1(rsa, data, a[i])}");
        sb.AppendLine($"→ 3 chữ ký giống nhau: {a[0].SequenceEqual(a[1]) && a[1].SequenceEqual(a[2])}\r\n");
        sb.AppendLine("== RSASSA-PSS (salt ngẫu nhiên 32 byte mỗi lần ký) ==");
        var b = Enumerable.Range(0, 3).Select(_ => SignatureService.SignPss(rsa, data)).ToList();
        for (int i = 0; i < 3; i++) sb.AppendLine($"Lần {i + 1}: {Convert.ToBase64String(b[i])[..40]}…  verify={SignatureService.VerifyPss(rsa, data, b[i])}");
        sb.AppendLine($"→ 3 chữ ký giống nhau: {b[0].SequenceEqual(b[1]) && b[1].SequenceEqual(b[2])}  (khác nhau nhưng đều hợp lệ)");
        sb.AppendLine($"→ Sửa 1 ký tự dữ liệu rồi verify: {SignatureService.VerifyPss(rsa, Encoding.UTF8.GetBytes(_sigIn.Text + "x"), b[0])}");
        _sigOut.Text = sb.ToString();
    }
}
